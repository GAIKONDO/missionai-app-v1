declare module 'plantuml-encoder' {
  export function encode(plantUmlCode: string): string;
}

